package com.test.constants;

public class Endpoints
{

	public static final String TestCase1="/employees";
	public static final String TestCase2="/create";
	public static final String TestCase3="/delete/{id}";
	public static final String TestCase4="/delete/{id}";
	public static final String  TestCase5="/employee/{id}";
}