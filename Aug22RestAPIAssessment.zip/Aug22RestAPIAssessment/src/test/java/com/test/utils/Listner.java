package com.test.utils;

import org.testng.ITestListener;

import com.test.helpers.UserServiceHelper;

public class Listner extends UserServiceHelper implements ITestListener{

}
